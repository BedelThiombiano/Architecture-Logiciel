<?php

        function connection()
        {
            $utilisateur = 'root';
            $pass = '';
            try
            {
                $bd =  new PDO('mysql:host=localhost;dbname=mglsi_news;charset=utf8mb4', $utilisateur, $pass);        
            } catch(PDOException $e)
            {
                print " Erreur : ". $e->getMessage(). " <br />";
                exit();
            }
            return $bd;
        }
    
        $bd=connection();
        $articles = Array();
?>

<!DOCTYPE html>
<html>
    <head>
        <title>HOME</title>
        <meta charset="utf-8"/>
        <link rel="stylesheet" type = "text/css" href="style.css" />
    </head>
    <body>
        <?php 
            foreach ($articles as $article): ?>
            <?php echo $article ?>
        <?php endforeach; ?>        
    </body>
</html>
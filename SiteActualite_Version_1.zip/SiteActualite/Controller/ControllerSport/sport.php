<?php

    require_once '../Modele/ModeleSport/sport.php';
    require '../articles.php'; 

?>
<?php
    Header ("Content-type: text/css; charset=utf-8");
    echo file_get_contents('style.css');
?>
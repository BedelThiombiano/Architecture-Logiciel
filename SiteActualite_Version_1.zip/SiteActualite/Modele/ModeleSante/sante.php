<?php
    require ("../connexion.php");
    $sql="SELECT * from article WHERE categorie = 3";
    foreach ($bd->query($sql) as $row)
    {
        $articles[]=$row;
    }
?>
<!DOCTYPE html>
    <html>
    <head>
        <title>HOME</title>
        <meta charset="utf-8"/>
        <link rel="stylesheet" type = "text/css" href="../../style.css" />
    </head>
    <body>
        Données reçues : <?= $_GET['id'] ?>
        <div class="menu">
                <ul>
                    <li><a href="../../../index.html">Acceuil</a></li>
                    <li><a href="../ModeleSport/sport.php">Sport</a></li>
                    <li><a href="#">Santé</a></li>
                    <li><a href="../ModeleEducation/education.php">Education</a></li>
                    <li><a href="../ModelePolitique/politique.php">Politique</a></li>
                </ul>
        </div>
        <?php 
            foreach ($articles as $article): ?>
            <h1>
                <?php 
                    echo $article[1];
                    ?>
            </h1>
            <p>
                <?php 
                    echo $article[2];
                ?>
            </p>
            <div>
                Date de creation : <?php echo $article[3]; ?> <br />
                Derniere modification : <?php echo $article[3]; ?>
            </div>   
        <?php endforeach; ?>  
        Bonjour    
    </body>
</html>

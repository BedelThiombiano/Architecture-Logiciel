<?php

    require_once '../Modele/ModelePolitique/politique.php';
    require '../articles.php';

?>
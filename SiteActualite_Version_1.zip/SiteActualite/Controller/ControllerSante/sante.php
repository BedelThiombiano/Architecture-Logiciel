<?php
    require_once '../Modele/ModeleSante/sante.php';
    require '../articles.php';
?>
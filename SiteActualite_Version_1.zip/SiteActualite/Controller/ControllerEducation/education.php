<?php
    require_once '../Modele/ModeleEducation/education.php';
    require '../articles.php';
?>